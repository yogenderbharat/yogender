package com.kanhaiyaorganics.callcrm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import org.json.JSONObject

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (state == TelephonyManager.EXTRA_STATE_IDLE) {
            val prefs = context.getSharedPreferences("crm", Context.MODE_PRIVATE)
            val api = prefs.getString("api", "") ?: ""
            val number = prefs.getString("active_number", "") ?: ""
            val started = prefs.getLong("start", 0L)
            if (api.isBlank() || number.isBlank()) return
            val duration = if (started > 0) ((System.currentTimeMillis()-started)/1000).coerceAtLeast(0) else 0
            Thread { try { ApiClient.post(api, "saveCall", JSONObject().apply { put("mobile", number); put("direction", "Unknown"); put("duration_seconds", duration); put("call_result", if(duration>0) "Answered" else "Missed"); put("source", "Direct call") }) } catch (_: Exception) {} }.start()
            prefs.edit().clear().apply()
        } else if (state == TelephonyManager.EXTRA_STATE_RINGING) {
            val n = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
            context.getSharedPreferences("crm", Context.MODE_PRIVATE).edit().putString("active_number", n).putLong("start", System.currentTimeMillis()).apply()
        } else if (state == TelephonyManager.EXTRA_STATE_OFFHOOK) {
            context.getSharedPreferences("crm", Context.MODE_PRIVATE).edit().putLong("start", System.currentTimeMillis()).apply()
        }
    }
}
