package com.kanhaiyaorganics.callcrm

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("crm", MODE_PRIVATE) }
    private val api get() = prefs.getString("api", "") ?: ""
    private lateinit var body: LinearLayout
    private val permission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(b: Bundle?) { super.onCreate(b); showDashboard() }
    private fun base(title:String): LinearLayout { val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(20,18,20,18); val bar=LinearLayout(this); bar.orientation=LinearLayout.HORIZONTAL; val t=TextView(this); t.text=title; t.textSize=24f; t.setTypeface(null,1); bar.addView(t,LinearLayout.LayoutParams(0,70,1f)); root.addView(bar); body=LinearLayout(this); body.orientation=LinearLayout.VERTICAL; root.addView(body,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root); return root }
    private fun btn(text:String, action:()->Unit){ Button(this).apply{ this.text=text; setOnClickListener{action()}; body.addView(this,LinearLayout.LayoutParams(-1,55).apply{setMargins(0,6,0,6)}) } }
    private fun showDashboard(){ base("Kanhaiya Organics CRM"); val status=TextView(this); status.text="Separate Calling CRM • Billing data untouched"; body.addView(status); btn("📊 Refresh Dashboard"){loadDashboard()}; btn("➕ New Call / Enquiry"){newCall()}; btn("📞 Calls"){list("getCalls","calls")}; btn("👥 Customers"){list("searchCustomers","customers")}; btn("📅 Follow-ups"){list("getFollowUps","followups")}; btn("⚙️ Settings"){settings()}; btn("🔐 Grant Call Permissions"){permission.launch(arrayOf(Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_CALL_LOG))}; loadDashboard() }
    private fun loadDashboard(){ if(api.isBlank()){return}; Thread{try{val j=ApiClient.get(api,"dashboard"); runOnUiThread{body.removeAllViews(); val d=j.optJSONObject("data")?:j; val s=d.optJSONObject("stats")?:d; arrayOf("Today Calls" to s.optInt("todayCalls"),"Hot Leads" to s.optInt("hotLeads"),"Follow-ups Today" to s.optInt("followUpsToday"),"Overdue" to s.optInt("overdueFollowUps"),"Converted" to s.optInt("converted"),"Total Customers" to s.optInt("totalCustomers"),"Total Calls" to s.optInt("totalCalls")).forEach{val v=TextView(this);v.text="${it.first}: ${it.second}";v.textSize=20f;v.setPadding(0,12,0,12);body.addView(v)}; btn("➕ New Call / Enquiry"){newCall()};btn("📅 Follow-ups"){list("getFollowUps","followups")};btn("🔎 Search Customers"){list("searchCustomers","customers")};btn("⚙️ Settings"){settings()} }}catch(e:Exception){runOnUiThread{Toast.makeText(this,"Dashboard error: ${e.message}",Toast.LENGTH_LONG).show()}}}.start() }
    private fun field(hint:String)=EditText(this).apply{this.hint=hint;setPadding(12,4,12,4);body.addView(this,LinearLayout.LayoutParams(-1,58).apply{setMargins(0,5,0,5)})}
    private fun newCall(){base("New Call / Enquiry");val mobile=field("Mobile number *");val name=field("Name");val city=field("City");val req=field("Requirement / Product");val qty=field("Quantity");val notes=field("Notes");btn("🔥 Save Hot Lead"){save(mobile,name,city,req,qty,notes,"Hot")};btn("Save Warm Lead"){save(mobile,name,city,req,qty,notes,"Warm")};btn("Save Cold Lead"){save(mobile,name,city,req,qty,notes,"Cold")};btn("← Back"){showDashboard()} }
    private fun save(m:EditText,n:EditText,c:EditText,r:EditText,q:EditText,no:EditText,p:String){val d=JSONObject().apply{put("mobile",m.text.toString());put("name",n.text.toString());put("city",c.text.toString());put("requirement",r.text.toString());put("quantity",q.text.toString());put("notes",no.text.toString());put("priority",p);put("status","New");put("source","Direct call")};Thread{try{val j=ApiClient.post(api,"saveCall",d);runOnUiThread{Toast.makeText(this,j.optString("message","Saved"),Toast.LENGTH_LONG).show();showDashboard()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Save failed",Toast.LENGTH_LONG).show()}}}.start()}
    private fun list(action:String,key:String){base(if(key=="calls")"Calls" else if(key=="customers")"Customers" else "Follow-ups");Thread{try{val j=ApiClient.get(api,action);val a=j.optJSONArray(key)?:JSONArray();runOnUiThread{for(i in 0 until a.length()){val o=a.optJSONObject(i)?:JSONObject();val v=TextView(this);v.text=o.toString(2);v.textSize=14f;v.setPadding(0,10,0,10);body.addView(v)};btn("← Back"){showDashboard()}}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Load failed",Toast.LENGTH_LONG).show()}}}.start()}
    private fun settings(){base("Settings");val e=field("Apps Script Web App /exec URL");e.setText(api);btn("Test Connection"){Thread{try{val j=ApiClient.get(e.text.toString().trim(),"ping");runOnUiThread{Toast.makeText(this,j.toString(),Toast.LENGTH_LONG).show()}}catch(x:Exception){runOnUiThread{Toast.makeText(this,x.message?:"Connection failed",Toast.LENGTH_LONG).show()}}}.start()};btn("Save API URL"){prefs.edit().putString("api",e.text.toString().trim()).apply();Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show()};btn("Open Billing App"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://example.com")))};btn("← Back"){showDashboard()} }
}
