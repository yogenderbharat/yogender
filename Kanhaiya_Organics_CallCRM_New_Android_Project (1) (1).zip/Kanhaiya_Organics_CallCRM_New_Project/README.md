# Kanhaiya Organics Call CRM — New Android Project

Standalone Android-first Calling & Enquiry CRM. Billing app and Billing Sheet remain separate.

## Build
GitHub Actions workflow: `.github/workflows/main.yml` — manually run it. It builds the project directly; no nested ZIP is needed.

## Backend
Set the Apps Script `/exec` URL in Settings. The app uses the Calling CRM API actions such as `ping`, `dashboard`, `saveCall`, `getCalls`, `searchCustomers`, and `getFollowUps`.
