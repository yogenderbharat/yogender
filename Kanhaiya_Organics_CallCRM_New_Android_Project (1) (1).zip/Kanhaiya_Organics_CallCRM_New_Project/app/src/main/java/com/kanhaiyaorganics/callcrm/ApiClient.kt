package com.kanhaiyaorganics.callcrm

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object ApiClient {
    fun get(url: String, action: String, data: JSONObject = JSONObject()): JSONObject {
        val sep = if (url.contains("?")) "&" else "?"
        val full = url + sep + "action=" + enc(action) + "&data=" + enc(data.toString())
        val c = URL(full).openConnection() as HttpURLConnection
        c.requestMethod = "GET"; c.connectTimeout = 15000; c.readTimeout = 20000
        return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    }
    fun post(url: String, action: String, data: JSONObject): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 20000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(JSONObject().put("action", action).put("data", data).toString().toByteArray()) }
        return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
